<?php

$appointments = new appointments();
$appointmentsList = $appointments->getAppointmentsList();


?>