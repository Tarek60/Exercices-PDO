<?php

$patients = new patients();
$patientsList = $patients->getPatientsList();
?>