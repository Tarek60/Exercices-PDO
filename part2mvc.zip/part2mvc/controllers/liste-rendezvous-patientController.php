<?php

$appointments = new appointments();
$appointmentInfo = $appointments->getAppointmentById();
?>